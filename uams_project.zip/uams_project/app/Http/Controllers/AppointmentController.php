<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Appointments;
use App\Models\User;
use App\Http\Controllers\HelperController;
use DB;
use Carbon\Carbon;
use Carbon\CarbonTimeZone;

class AppointmentController extends Controller
{
    public function getAppointments()
    {
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('signIn')->with('error', 'Silakan login terlebih dahulu.');
        }

        // Ambil daftar meeting dengan status
        $appointments = Appointments::where('creator_id', $user->id)
            ->orWhereHas('participants', function ($query) use ($user) {
                $query->where('users.id', $user->id);
            })
            ->with('creator')
            ->get()
            ->map(function ($appointment) use ($user) {
                $appointment->status = $appointment->creator_id === $user->id ? 'Created' : 'Invited';
                return $appointment;
            });

        return view('m_appointment.index', compact('user', 'appointments'));
    }




    function getAddAppointments()
    {
        return view('m_appointment.add', [
        ]);
    }


    function postAddAppointments(Request $request)
    {
        // Debugging jika diperlukan
        // dd($request->all());
        // dd(Auth::id());

        // Validasi request
        $request->validate([
            'title' => 'required|string|max:255',
            'start_datetime' => 'required|date_format:Y-m-d H:i|after:now',
            'end_datetime' => 'required|date_format:Y-m-d H:i|after:start_datetime',
        ]);

        // Simpan ke database
        $appointment = Appointments::create([
            'title' => $request->title,
            'creator_id' => Auth::id(), // ID user yang sedang login
            'start' => $request->start_datetime,
            'end' => $request->end_datetime,
        ]);

        // Jika gagal membuat janji temu
        if (!$appointment) {
            return app(HelperController::class)->Negative('getAppointments');
        }

        // Jika berhasil
        return app(HelperController::class)->Positive('getAppointments');
    }


    function getEditAppointments(Request $request)
    {
        $datanow = DB::table('appointments')
            ->where('appointments.id', $request->id)
            ->select('id', 'title', 'start', 'end', 'creator_id') // Ambil hanya yang dibutuhkan
            ->first();

        // dd($datanow);
        return view('m_appointment.edit', [
            'datanow' => $datanow,
        ]);
    }


    function postEditAppointments(Request $request)
    {
        // dd($request);

        $update = Appointments::where('id', $request->id)
            ->update([
                'title' => $request->title,
                'start' => $request->start_datetime,
                'end' => $request->end_datetime,
            ]);
        

        if ($update) {
            return app(HelperController::class)->Positive('getAppointments');
        } else {
            return app(HelperController::class)->Warning('getAppointments');
        }
    }

    public function getInvitedUsers(Request $request)
    {
        // $invitedUsers = DB::table('appointment_users')
        //     ->join('users', 'appointment_users.user_id', '=', 'users.id')
        //     ->where('appointment_users.appointment_id', $request->id)
        //     ->select('users.id', 'users.name','users.preferred_timezone')
        //     ->get();

        $invitedUsers = User::join('appointment_users', 'users.id', '=', 'appointment_users.user_id')
            ->where('appointment_users.appointment_id', $request->id)
            ->select('users.id', 'users.name', 'users.preferred_timezone')
            ->get();
        // dd($invitedUsers);

        return view('m_appointment.indexusers', compact('invitedUsers'))->with('appointmentId', $request->id);
    }

    public function getAddInvitedUsers(Request $request)
    {
        // Ambil data appointment + timezone creator
        $appointment = DB::table('appointments')
            ->join('users', 'appointments.creator_id', '=', 'users.id')
            ->where('appointments.id', $request->id)
            ->select('appointments.*', 'users.preferred_timezone as creator_timezone', 'users.id as creator_id')
            ->first();

        if (!$appointment) {
            return response()->json(['error' => 'Appointment not found'], 404);
        }

        $creatorTz = new CarbonTimeZone($appointment->creator_timezone);

        // Ambil daftar user yang sudah diundang ke meeting ini
        $invitedUsers = DB::table('appointment_users')
            ->join('users', 'appointment_users.user_id', '=', 'users.id')
            ->where('appointment_users.appointment_id', $request->id)
            ->select('users.*') // Ambil semua informasi user yang sudah diundang
            ->get();

        // Ambil semua users yang bukan creator dan belum terdaftar dalam meeting
        $users = DB::table('users')
            ->where('id', '!=', $appointment->creator_id)
            ->whereNotIn('id', $invitedUsers->pluck('id')) // Pastikan tidak mengambil yang sudah diundang
            ->get();

        // List user yang bisa ikut meeting
        $availableUsers = [];

        foreach ($users as $user) {
            $userTz = new CarbonTimeZone($user->preferred_timezone ?? 'UTC'); // Default ke UTC jika null

            // Konversi start & end ke timezone user
            $startUserTz = Carbon::parse($appointment->start, $creatorTz)->setTimezone($userTz);
            $endUserTz = Carbon::parse($appointment->end, $creatorTz)->setTimezone($userTz);

            // Cek apakah start & end dalam jam kerja (09:00 - 17:00)
            if ($startUserTz->format('H:i') >= '09:00' && $startUserTz->format('H:i') <= '17:00' &&
                $endUserTz->format('H:i') >= '09:00' && $endUserTz->format('H:i') <= '17:00') {
                $availableUsers[] = $user;
            }
        }

        // dd($availableUsers);
        return view('m_appointment.addusers', compact('availableUsers', 'invitedUsers', 'appointment'));

    }

    public function postAddInvitedUsers(Request $request)
    {
        $appointmentId = $request->id;

        // Cek apakah meeting (appointment) ada
        $appointment = Appointments::find($appointmentId);
        if (!$appointment) {
            return app(HelperController::class)->Negative('getInvitedUsers');
        }

        // Hapus user yang dipilih dari daftar undangan
        if ($request->invited_users_old) {
            $appointment->participants()->detach($request->invited_users_old);
        }

        // Tambahkan user baru ke daftar undangan
        if ($request->available_users) {
            $appointment->participants()->attach($request->available_users);
        }

        // Simpan perubahan & return response
        return app(HelperController::class)->Positive('getInvitedUsers', ['id' => $appointment->id]);


    }
}
