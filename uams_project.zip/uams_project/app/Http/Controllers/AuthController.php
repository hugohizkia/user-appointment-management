<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Appointments;
use Carbon\Carbon;
use DateTimeZone;
use App\Models\Course;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class AuthController extends Controller
{
    public function index()
    {
        return view('index');
    }

    public function showRegisterForm()
    {
        
        if (auth()->check()) {
            return redirect()->route('getAppointments'); // Ganti dengan route home yang sesuai
        }
        $timezones = DateTimeZone::listIdentifiers();
        return view('user.register', compact('timezones'));
    }

    
    public function postSignUp(Request $request)
    {
        $validated = $request->validate([
            'username' => 'required|unique:users,username',
            'name' => 'required|string',
            'preferred_timezone' => 'required|string'
        ]);

        // Simpan user ke database
        $createMember = User::create([
            'username' => $validated['username'],
            'name' => $validated['name'],
            'preferred_timezone' => $validated['preferred_timezone'],
        ]);

        if ($createMember) {
            return redirect()->route('login', ['direct' => 1]);
        } else {
            return redirect()->back()->with('error', 'Pendaftaran gagal, coba lagi.');
        }
    }

    // Untuk memproses form pendaftaran bootcamp dan produk lainnya
    public function postSignIn(Request $request)
    {
        $validated = $request->validate([
            'username' => 'required|exists:users,username',
        ]);

        $user = User::where('username', $validated['username'])->first();

        if ($user) {
            Auth::login($user);
            session()->regenerate(); // Regenerasi session agar lebih aman

            return redirect()->route('getAppointments');
        }

        return back()->with('signInFailed', true);
    }




    function handlePost($email)
    {
        if (Auth::guard('web')->attempt(['email' => $email, 'password' => 'default'])) {
            echo '<script>window.location.href = "' . route('lms.dashboard') . '";</script>';
        } else {
            echo '<script>window.history.back();</script>';
        }
    }

    public function postLogout(Request $request)
    {
        Auth::logout(); // Logout user
        $request->session()->invalidate(); // Hapus semua session
        $request->session()->regenerateToken(); // Regenerasi CSRF token

        return redirect()->route('login')->with('message', 'Anda telah logout.');
    }

}
