<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Appointments extends Model
{
    public $table = 'appointments';

    protected $fillable = [
        'title',
        'creator_id',
        'start',
        'end',
        'created_at',
        'updated_at',
    ];

    public function creator()
    {
        return $this->belongsTo(User::class, 'creator_id');
    }

    // Relasi ke users yang diundang dalam meeting (many-to-many)
    public function participants()
    {
        return $this->belongsToMany(User::class, 'appointment_users', 'appointment_id', 'user_id');
    }
}
