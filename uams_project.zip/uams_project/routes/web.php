<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\AuthController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/login', function () {
    return view('user.login');
})->name('login');

Route::post('/login', [AuthController::class, 'postSignIn'])->name('postSignIn');
Route::post('/logout', [AuthController::class, 'postLogout'])->name('logout');

Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register');

Route::post('/register', [AuthController::class, 'postSignUp'])->name('postSignUp');

Route::post('/register', [AuthController::class, 'postSignUp'])->name('postSignUp');

Route::get('/appointments', [AppointmentController::class, 'getAppointments'])->name('getAppointments');

Route::get('/appointments/add', [AppointmentController::class, 'getAddAppointments'])->name('getAddAppointments');
Route::post('/appointments/add', [AppointmentController::class, 'postAddAppointments'])->name('postAddAppointments');

Route::get('/appointments/edit', [AppointmentController::class, 'getEditAppointments'])->name('getEditAppointments');
Route::post('/appointments/edit', [AppointmentController::class, 'postEditAppointments'])->name('postEditAppointments');

Route::get('/invitedusers', [AppointmentController::class, 'getInvitedUsers'])->name('getInvitedUsers');
Route::get('/invitedusers/add', [AppointmentController::class, 'getAddInvitedUsers'])->name('getAddInvitedUsers');
Route::post('/invitedusers/add', [AppointmentController::class, 'postAddInvitedUsers'])->name('postAddInvitedUsers');