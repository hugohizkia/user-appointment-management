<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalender Mary UI</title>
    <script src="https://cdn.jsdelivr.net/npm/vanilla-calendar-pro@2.9.6/build/vanilla-calendar.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/vanilla-calendar-pro@2.9.6/build/vanilla-calendar.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .event-day {
            background-color: #fbbf24 !important;
            color: white !important;
            border-radius: 50%;
            font-weight: bold;
            position: relative;
        }
        /* tooltip style */
        .event-day:hover::after {
            content: attr(data-title);
            position: absolute;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            background: black;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 12px;
            white-space: nowrap;
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">
    <div class="bg-white p-6 rounded-lg shadow-lg">
        <h2 class="text-xl font-bold mb-4">Kalender Multiple dengan Event</h2>
        <div id="calendar"></div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const events = [
                { date: "2025-02-25", title: "Meeting Tim" },
                { date: "2025-02-28", title: "Presentasi Proyek" },
                { date: "2025-03-05", title: "Deadline Pengumpulan Laporan" }
            ];

            const calendar = new VanillaCalendar("#calendar", {
                settings: {
                    visibility: {
                        weekend: true
                    },
                    selection: {
                        multiple: true
                    },
                    view: {
                        months: 3, // tampilkan 3 bulan sekaligus
                        width: 3
                    }
                },
                actions: {
                    clickDay(event, self) {
                        const selectedDate = self.date.current;
                        const eventDetails = events.find(e => e.date === selectedDate);
                        if (eventDetails) {
                            alert(`Event: ${eventDetails.title} pada ${selectedDate}`);
                        }
                        highlightEvents();
                    }
                }
            });

            calendar.init();

            // fungsi untuk menandai event
            function highlightEvents() {
                events.forEach(event => {
                    const dayElements = document.querySelectorAll(`[data-calendar-day="${event.date}"]`);
                    dayElements.forEach(dayElement => {
                        dayElement.classList.add("event-day");
                        dayElement.setAttribute("data-title", event.title);
                    });
                });
            }

            // panggil fungsi pertama kali
            highlightEvents();

            // observer untuk mendeteksi perubahan kalender
            const observer = new MutationObserver(() => {
                highlightEvents();
            });

            observer.observe(document.querySelector("#calendar"), { childList: true, subtree: true });
        });
    </script>
</body>
</html>
