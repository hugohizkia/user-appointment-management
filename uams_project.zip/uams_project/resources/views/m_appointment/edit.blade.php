@extends('layout.master')

@section('title', 'Edit Meeting')

@section('content') 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-ui-timepicker-addon/1.6.3/jquery-ui-timepicker-addon.min.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-ui-timepicker-addon/1.6.3/jquery-ui-timepicker-addon.min.js"></script>

<div style="padding: 12px 12px 0px 12px;">
    <h2>Edit Meeting</h2>
    <hr><br>
    <form class="ui form" method="post" action="{{ route('postEditAppointments') }}">
        @csrf
        <input type="hidden" name="id" value="{{ $datanow->id }}">

        <div class="field">
            <label for="title">Meeting Title*</label>
            <input type="text" name="title" value="{{ $datanow->title }}" required>
        </div>
        <div class="two fields">
            <div class="field">
                <label for="start_datetime">Start Date & Time*</label>
                <input type="text" id="start_datetime" name="start_datetime" value="{{ $datanow->start }}" required>
            </div>
            <div class="field">
                <label for="end_datetime">End Date & Time*</label>
                <input type="text" id="end_datetime" name="end_datetime" value="{{ $datanow->end }}" required>
            </div>
        </div>

        <button type="submit" class="ui button primary">Update Meeting</button>
    </form>
    <a href="{{ url()->previous() }}"><button class="right floated ui red button">Cancel</button></a>
    <br><br>
</div>

<script>
    $(function() {
        $("#start_datetime, #end_datetime").datetimepicker({
            dateFormat: "yy-mm-dd",
            timeFormat: "HH:mm",
            changeYear: true,
            changeMonth: true
        });
    });
</script>
@endsection
