

<?php $__env->startSection('title', 'Edit Meeting Member'); ?>

<?php $__env->startSection('content'); ?>
<!-- Tambahkan CSS Bootstrap & Multiselect -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.15/css/bootstrap-multiselect.css" />
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">

<!-- Tambahkan jQuery & Multiselect JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.15/js/bootstrap-multiselect.min.js"></script>

<div class="px-3 pb-3">
    <h2>Edit Meeting Member</h2>
    <hr style="padding-bottom:1%">
    <form class="ui form" action="<?php echo e(route('postAddInvitedUsers', ['id' => request()->query('id')])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="field">
            <div class="two fields">
                <div class="field">
                    <label>ID</label>
                    <input type="text" value="<?php echo e($appointment->id); ?>" disabled>
                    <input type="hidden" name="appointment_id" value="<?php echo e($appointment->id); ?>">
                </div>

                <div class="field">
                    <label>Title</label>
                    <input type="text" name="name" value="<?php echo e($appointment->title); ?>">
                </div>
            </div>
            <div class="two fields">
                <div class="field">
                    <label>User yang sudah diundang:</label>
                    <small>Pilih untuk hapus dari meeting</small>
                    <select id="hapus" name="invited_users_old[]" multiple="multiple" class="form-control">
                        <?php $__currentLoopData = $invitedUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="field">
                    <label>User yang belum diundang:</label>
                    <small>Pilih untuk tambah ke meeting</small>
                    <select id="tambah" name="available_users[]" multiple="multiple" class="form-control">
                        <?php $__currentLoopData = $availableUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </div>
        <button class="right floated ui button primary">Save & Update</button>
    </form>
    <a href="<?php echo e(route('getInvitedUsers', ['id' => request()->query('id')])); ?>">
    <button class="right floated ui red button">Batal</button>
</a>

</div>

<script>
    $(document).ready(function() {
        console.log("Script Multiselect dijalankan");

        if ($('#hapus').length > 0 && $('#tambah').length > 0) {
            $('#hapus, #tambah').multiselect({
                maxHeight: 300,
                includeSelectAllOption: true,
                buttonClass: '',
                enableFiltering: true,
            });
        } else {
            console.error("Element #hapus atau #tambah tidak ditemukan!");
        }
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Hugo.H\xampp\htdocs\uams_project\resources\views/m_appointment/addusers.blade.php ENDPATH**/ ?>