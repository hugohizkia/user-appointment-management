<!-- style css -->
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<!-- Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
<!-- jQuery (Dibutuhkan oleh Select2) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

<style>
    .select2-container .select2-selection--single {
    height: 38px; /* Samakan dengan input Bootstrap */
    padding: 1px 4px; 
    display: flex;
    align-items: center; /* Pastikan teks dan panah sejajar */
}

.select2-container .select2-selection__arrow {
    height: 38px; /* Sesuaikan tinggi panah */
    top: 50%;
    transform: translateY(20%); /* Pastikan panah sejajar */
}

</style>



<!-- Register Section -->
<section class="container-fluid register h-100">
    <!-- untuk layar besar -->
    <div class="d-md-none d-xl-block h-100">
        <div class="row h-100">
            <div class="col-lg-6">
                <div class="header text-center my-5">
                    <h1>Create an account</h1>
                </div>
                <div class="register-form mx-auto">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <div style="display: flex; flex-direction: column; gap: 5px;">
                            <label for="username">Input Username:*</label>
                            <input class="form-control" id="username" name="username" placeholder="Enter Your Username">
                            <?php $__currentLoopData = $errors->get('username'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span style="color: red;"><?php echo e($error); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div style="display: flex; flex-direction: column; gap: 5px;">
                            <label for="name">Input Name:*</label>
                            <input class="form-control" id="name" name="name" placeholder="Enter Your Name">
                            <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span style="color: red;"><?php echo e($error); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div style="display: flex; flex-direction: column; gap: 5px; margin-top: 10px;">
                            <label for="timezone">Pilih Zona Waktu:*</label>
                            <select id="timezone" name="preferred_timezone" class="form-control" style="width: 100%;">
                                <option value="" disabled selected>Pilih Zona Waktu</option>
                                <?php $__currentLoopData = $timezones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timezone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($timezone); ?>"><?php echo e($timezone); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>




                        <button class="signup" type="submit">Sign Up</button>
                    </form>
                    <span class="signup-txt">Already have an account? <a href="/login"style="text-decoration: underline; color:blue;">Sign In</a></span>

                </div>
            </div>
            <div class="col-lg-6 right">
                <div class="d-flex align-items-end h-100">

                </div>
            </div>
        </div>
    </div>

    <!-- untuk layar kecil/sedang (tablet, hp) -->
    <div class="d-none d-md-block d-xl-none h-100" style="margin:auto;">
        <h1 style="text-align:center; margin-left:auto; margin-right:auto;">Create an account</h1>
        <div class="register-form" style="margin:auto; width:65%">
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <input type="email" class="form-control" id="email" name="email" placeholder="Enter Your Email">
                <?php $__currentLoopData = $errors->get('email'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span style="color: red;"><?php echo e($error); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <input type="password" class="form-control" id="password" name="password"
                       placeholder="Enter Your Password">
                <?php $__currentLoopData = $errors->get('password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span style="color: red;"><?php echo e($error); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <input type="password" class="form-control" id="confirm" name="confirm_password"
                       placeholder="Confirm Password">
                <?php $__currentLoopData = $errors->get('confirm_password'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span style="color: red;"><?php echo e($error); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button class="signup" type="submit">Sign Up</button>
            </form>
            <span class="signup-txt">Already have an account? <a href="<?php echo e(route('login')); ?>"
                                                                 style="text-decoration: underline; color:blue;">Sign In</a></span>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#timezone').select2({
                placeholder: "Pilih Zona Waktu",
                allowClear: true,
                width: '100%' // Menyesuaikan lebar dengan input lain
            });
        });
    </script>


</section>


<?php /**PATH E:\Hugo.H\xampp\htdocs\uams_project\resources\views/user/register.blade.php ENDPATH**/ ?>