<!-- style css -->
<link rel="stylesheet" href="/css/style.css">
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" type="text/css"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">

<!-- Login Section -->
<section class="container-fluid login h-100">
    <div class="d-md-none d-xl-block h-100">
        <div class="row h-100">
            <div class="col-lg-6">
                <div class="header text-center my-5">
                    <h1 class="fs-1">Sign In</h1>
                </div>
                <div class="login-form mx-auto">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                            <div style="display: flex; flex-direction: column; gap: 5px;">
                                <label for="username">Input Username:*</label>
                                <input class="form-control" id="username" name="username" placeholder="Enter Your Username">
                                <?php $__currentLoopData = $errors->get('username'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span style="color: red;"><?php echo e($error); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        <button class="signin" type="submit">Sign In</button>

                        
                        <span class="signin-txt">
                            Dont have an account? <a href="<?php echo e(route('register')); ?>"style="text-decoration: underline; color:blue;">Sign Up</a>
                        </span>

                    </form>
                </div>
            </div>
            <div class="col-lg-6 right">
                <div class="d-flex align-items-end h-100">
                    
                </div>
            </div>
        </div>
    </div>
</section>

<?php /**PATH E:\Hugo.H\xampp\htdocs\uams_project\resources\views/user/login.blade.php ENDPATH**/ ?>